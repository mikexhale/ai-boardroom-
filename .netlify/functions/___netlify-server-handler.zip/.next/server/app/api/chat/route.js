"use strict";(()=>{var e={};e.id=744,e.ids=[744],e.modules={517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3472:(e,t,a)=>{a.r(t),a.d(t,{headerHooks:()=>g,originalPathname:()=>v,patchFetch:()=>y,requestAsyncStorage:()=>u,routeModule:()=>p,serverHooks:()=>h,staticGenerationAsyncStorage:()=>m,staticGenerationBailout:()=>f});var s={};a.r(s),a.d(s,{POST:()=>d});var o=a(5419),r=a(9108),i=a(9678),n=a(8070),l=a(4069),c=a(1850);async function d(e){try{let{message:t,expertId:a,sessionHistory:s,messageType:o,selectedExperts:r}=await e.json(),i=!!process.env.OPENROUTER_API_KEY,d=process.env.OPENROUTER_API_KEY?.length||0;if(console.log("OpenRouter API Key configured:",i),console.log("OpenRouter API Key length:",d),console.log("Environment variables available:",Object.keys(process.env).filter(e=>e.includes("OPENROUTER")||e.includes("SUPABASE"))),!process.env.OPENROUTER_API_KEY){console.log("Falling back to demo mode - no OpenRouter API key found");let e="",s="assistant",i="",l="",d="";if(a){let o=c.find(e=>e.id===a);if(!o)return n.Z.json({error:"Expert not found"},{status:404});i=o.name,l=o.avatar,d=o.title;let r=o.expertise[0]?.toLowerCase()||"their field",p=o.personality.style.toLowerCase();e=`${o.name} (${o.title}): Thank you for the question about "${t}". As a ${p} professional with expertise in ${r}, I see several key considerations. From my perspective, we should focus on strategic positioning and market opportunity. My ${r} background suggests we need to consider both immediate tactical needs and long-term strategic implications. I recommend a balanced approach that leverages our core strengths while addressing the specific challenges you've outlined.`,s="expert"}else if("moderator"===o){if(s="moderator",r&&r.length>0){let a=r.map(e=>{let t=c.find(t=>t.id===e);if(!t)return"";let a=t.expertise[0]?.toLowerCase()||"their field";return`- ${t.name} (${t.title}): Please analyze this from your ${a} perspective. What strategic insights can you provide?`}).filter(Boolean);e=`Thank you for presenting this challenge: "${t}". Let me direct this to our expert board members for their specialized analysis.

${a.join("\n")}

Please provide your expert insights based on your respective areas of expertise.`}else e=`Thank you for your question: "${t}". Let me facilitate a discussion among our board members to address this important point. The board acknowledges your inquiry and will provide comprehensive insights based on our collective expertise.`}else if("board-synthesis"===o){if(s="moderator",r&&r.length>0){let a=r.map(e=>{let t=c.find(t=>t.id===e);return t?.name||"Board Member"}).join(", ");e=`**BOARD SYNTHESIS SUMMARY**

Based on our comprehensive discussion of "${t}", here's our collective analysis:

**Key Insights from Our Expert Team:**
- Strategic Perspective: Focus on market positioning and competitive advantage
- Innovation Angle: Identify disruptive opportunities and technological leverage
- Financial Considerations: Balance risk and return for sustainable growth
- Operational Excellence: Streamline processes for maximum efficiency

**Consensus Recommendations:**
1. Conduct thorough market analysis
2. Develop clear implementation roadmap
3. Establish measurable success metrics
4. Monitor progress and adjust strategy as needed

**Next Steps:**
Our expert team recommends immediate action on the highest-impact areas while maintaining flexibility for emerging opportunities.

This synthesis represents the collective wisdom of: ${a}`}else e=`**BOARD SYNTHESIS**

The board has analyzed your challenge and identified key strategic areas for consideration. We recommend a comprehensive approach that balances immediate needs with long-term sustainability.`}else s="board",e=`The board has analyzed your question: "${t}". As a collective, we've identified key strategic areas for consideration. We recommend a comprehensive approach that balances immediate needs with long-term sustainability. Each of our expert board members brings unique insights to this discussion.`;return n.Z.json({response:e,role:s,expertName:i,expertAvatar:l,expertTitle:d,timestamp:new Date().toISOString(),tokens:0,model:"demo",cost:0})}if(console.log("Using OpenRouter for AI responses"),a){let e=c.find(e=>e.id===a);if(!e)return n.Z.json({error:"Expert not found"},{status:404});let o={id:e.id,name:e.name,title:e.title,expertise:e.expertise,personality:e.personality,background:e.personality.background,communication:e.personality.communication};try{console.log("Calling generateAIResponse for expert:",a);let r=await (0,l.U6)(t,a,o,s);return console.log("AI Response received:",{model:r.model,tokens:r.tokens}),n.Z.json({response:r.response,role:"expert",expertName:e.name,expertAvatar:e.avatar,expertTitle:e.title,timestamp:new Date().toISOString(),tokens:r.tokens,model:r.model,cost:r.cost})}catch(e){return console.error("Error calling OpenRouter:",e),n.Z.json({error:"Failed to generate AI response",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}else if("moderator"===o){let e=`As the Board Moderator, please address the following challenge:

CHALLENGE: ${t}

YOUR ROLE:
1. Clarify and restate the challenge to ensure all experts understand
2. Provide relevant context and background
3. Direct each expert to focus on their specific area of expertise
4. Ensure responses are grounded in facts and expertise
5. Maintain focus and prevent discussion drift
6. Structure the conversation for maximum value

Please provide a clear, structured response that:
- Restates the challenge clearly
- Provides relevant context
- Directs experts to their areas of expertise
- Sets expectations for evidence-based responses
- Maintains professional facilitation tone`,a=await (0,l.U6)(e,"moderator",{id:"moderator",name:"Board Moderator",title:"Session Facilitator",expertise:["Facilitation","Coordination","Synthesis","Strategic Guidance"],personality:{style:"Professional and facilitative",traits:["Organized","Clear","Diplomatic","Structured"]},background:"Experienced board session facilitator with expertise in strategic discussion management",communication:"Clear, professional, facilitative, and focused on outcomes"},s);return n.Z.json({response:a.response,role:"moderator",expertName:"Board Moderator",expertAvatar:"\uD83D\uDC68‍\uD83D\uDCBC",expertTitle:"Session Facilitator",timestamp:new Date().toISOString(),tokens:a.tokens,model:a.model,cost:a.cost})}else if("board-synthesis"===o){let e=`As the Board Synthesis Expert, please create a comprehensive summary of our discussion:

ORIGINAL CHALLENGE: ${t}

SYNTHESIS REQUIREMENTS:
1. **Executive Summary**: 2-3 sentences capturing the core challenge
2. **Expert Insights**: Key points from each expert's analysis (focus on their actual expertise areas)
3. **Strategic Analysis**: Evidence-based insights, not speculation
4. **Actionable Recommendations**: Specific, implementable next steps
5. **Risk Assessment**: Realistic risks and mitigation strategies
6. **Implementation Roadmap**: Clear timeline and milestones

HALLUCINATION PREVENTION:
- Base all insights on the actual expert responses provided
- Focus on evidence and expertise, not speculation
- Avoid making claims without supporting expert input
- Stay grounded in the specific challenge presented
- Use concrete, actionable language

Please provide a structured synthesis that is:
- Evidence-based and grounded in expert input
- Actionable and specific
- Professional and comprehensive
- Focused on the actual challenge presented`,a=await (0,l.U6)(e,"sarah-chen",{id:"synthesis",name:"Board Synthesis",title:"Strategic Summary",expertise:["Strategic Analysis","Synthesis","Decision Making","Evidence-Based Recommendations"],personality:{style:"Analytical and comprehensive",traits:["Thorough","Strategic","Comprehensive","Evidence-Based"]},background:"Expert in synthesizing diverse perspectives into actionable strategic insights",communication:"Clear, comprehensive, evidence-based, and actionable"},s);return n.Z.json({response:a.response,role:"moderator",expertName:"Board Synthesis",expertAvatar:"\uD83D\uDCCA",expertTitle:"Strategic Summary",timestamp:new Date().toISOString(),tokens:a.tokens,model:a.model,cost:a.cost})}else{let e=await (0,l.U6)(t,"sarah-chen",{id:"board",name:"AI Board",title:"Collective Intelligence",expertise:["Strategic Planning","Multi-disciplinary Analysis"],personality:{style:"Collaborative and comprehensive",traits:["Analytical","Strategic","Comprehensive"]},background:"Collective AI board intelligence",communication:"Professional and comprehensive"},s);return n.Z.json({response:e.response,role:"board",expertName:"AI Board",expertAvatar:"\uD83C\uDFE2",expertTitle:"Collective Intelligence",timestamp:new Date().toISOString(),tokens:e.tokens,model:e.model,cost:e.cost})}}catch(e){return console.error("Chat API error:",e),n.Z.json({error:"Failed to generate response. Please try again."},{status:500})}}let p=new o.AppRouteRouteModule({definition:{kind:r.x.APP_ROUTE,page:"/api/chat/route",pathname:"/api/chat",filename:"route",bundlePath:"app/api/chat/route"},resolvedPagePath:"/Users/thaerahmad/AI board /app/api/chat/route.ts",nextConfigOutput:"standalone",userland:s}),{requestAsyncStorage:u,staticGenerationAsyncStorage:m,serverHooks:h,headerHooks:g,staticGenerationBailout:f}=p,v="/api/chat/route";function y(){return(0,i.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:m})}}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[638,206,834],()=>a(3472));module.exports=s})();