(()=>{var e={};e.id=566,e.ids=[566],e.modules={517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4300:e=>{"use strict";e.exports=require("buffer")},6113:e=>{"use strict";e.exports=require("crypto")},2361:e=>{"use strict";e.exports=require("events")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},1808:e=>{"use strict";e.exports=require("net")},5477:e=>{"use strict";e.exports=require("punycode")},2781:e=>{"use strict";e.exports=require("stream")},4404:e=>{"use strict";e.exports=require("tls")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},8359:()=>{},948:()=>{},2834:(e,t,r)=>{"use strict";r.r(t),r.d(t,{headerHooks:()=>x,originalPathname:()=>S,patchFetch:()=>v,requestAsyncStorage:()=>y,routeModule:()=>g,serverHooks:()=>I,staticGenerationAsyncStorage:()=>b,staticGenerationBailout:()=>f});var s={};r.r(s),r.d(s,{POST:()=>h});var a=r(5419),o=r(9108),i=r(9678),n=r(8070),p=r(1971);r(7497);let c="https://zpieirssvbviljaatuvl.supabase.co",l="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpwaWVpcnNzdmJ2aWxqYWF0dXZsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQyMjIxMDUsImV4cCI6MjA2OTc5ODEwNX0.3i2gpQqRh_p73nmrLPk5sly-qKB_kI3-bglXYzhYfzQ",d=c&&l?(0,p.eI)(c,l):null;var u=r(4069),m=r(1850);async function h(e){try{let{prompt:t,expertIds:r,flow:s="moderated"}=await e.json();if(!t)return n.Z.json({error:"Prompt is required"},{status:400});let a=m.filter(e=>r.includes(e.id));if(0===a.length)return n.Z.json({error:"No valid experts selected"},{status:400});if(!process.env.OPENROUTER_API_KEY){let e=`BOARD MEETING SUMMARY

CASE BRIEF: ${t}

EXPERT ANALYSIS:
${a.map(e=>`- ${e.name} (${e.title}): Based on my expertise in ${e.expertise[0]?.toLowerCase()}, I recommend focusing on strategic positioning and market opportunity. My ${e.personality.style} approach suggests we should consider both short-term and long-term implications.`).join("\n")}

SYNTHESIS:
The board has analyzed your challenge and identified key strategic areas for consideration. We recommend a comprehensive approach that balances immediate needs with long-term sustainability.

RECOMMENDATIONS:
1. Conduct thorough market analysis
2. Develop clear implementation roadmap
3. Establish measurable success metrics
4. Monitor progress and adjust strategy as needed

This is a demo response. Configure your OpenRouter API key for real AI-generated strategic analysis.`;if(d)try{let{data:r,error:o}=await d.from("memos").insert([{content:e,created_at:new Date().toISOString(),metadata:{expert_count:a.length,experts:a.map(e=>e.name),prompt_length:t.length,model:"demo",tokens_used:0,flow_type:s,stages_completed:["brief","round-robin","debate","synthesis"]}}]).select().single();o&&console.error("Supabase error:",o)}catch(e){console.error("Supabase connection error:",e)}return n.Z.json({content:e,experts:a.map(e=>e.name),model:"demo",tokens:0,cost:0})}let o=`Please provide a comprehensive board meeting summary for the following strategic challenge:

CHALLENGE: ${t}

SELECTED EXPERTS:
${a.map(e=>`- ${e.name} (${e.title}): ${e.expertise.join(", ")}`).join("\n")}

Please provide:
1. Executive Summary
2. Expert Analysis from each selected expert's perspective
3. Key Strategic Insights
4. Recommendations and Action Items
5. Risk Assessment
6. Implementation Roadmap

Format this as a professional board meeting summary.`,i=await (0,u.U6)(o,"sarah-chen",{id:"board-synthesis",name:"AI Board Synthesis",title:"Strategic Analysis Team",expertise:["Strategic Planning","Multi-disciplinary Analysis","Synthesis"],personality:{style:"Analytical and comprehensive",traits:["Strategic","Analytical","Comprehensive"]},background:"Expert AI board providing strategic analysis",communication:"Professional, comprehensive, and actionable"}),p=i.response;if(d)try{let{data:e,error:r}=await d.from("memos").insert([{content:p,created_at:new Date().toISOString(),metadata:{expert_count:a.length,experts:a.map(e=>e.name),prompt_length:t.length,model:i.model,tokens_used:i.tokens,cost:i.cost,flow_type:s,stages_completed:["brief","round-robin","debate","synthesis"]}}]).select().single();r&&console.error("Supabase error:",r)}catch(e){console.error("Supabase connection error:",e)}return n.Z.json({content:p,experts:a.map(e=>e.name),model:i.model,tokens:i.tokens,cost:i.cost})}catch(e){return console.error("Board API error:",e),n.Z.json({error:"Failed to generate board summary. Please try again."},{status:500})}}let g=new a.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/board/route",pathname:"/api/board",filename:"route",bundlePath:"app/api/board/route"},resolvedPagePath:"/Users/thaerahmad/AI board /app/api/board/route.ts",nextConfigOutput:"standalone",userland:s}),{requestAsyncStorage:y,staticGenerationAsyncStorage:b,serverHooks:I,headerHooks:x,staticGenerationBailout:f}=g,S="/api/board/route";function v(){return(0,i.patchFetch)({serverHooks:I,staticGenerationAsyncStorage:b})}}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[638,206,497,834],()=>r(2834));module.exports=s})();